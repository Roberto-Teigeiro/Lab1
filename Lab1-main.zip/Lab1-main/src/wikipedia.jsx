const Wikipedia = () => {

    
    
    return (


        <div className="center-align">
            <h2>Wikimedia API</h2>
            <p></p>
            
            
            
            
            
            
        </div>




    )

}

export default Wikipedia